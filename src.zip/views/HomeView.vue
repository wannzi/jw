<template>
  <div>
    <!-- 登录表单 -->
    home
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: '',
      password: ''
    };
  },
  methods: {
    login() {
      // 调用登录API并处理响应
    }
  }
};
</script>